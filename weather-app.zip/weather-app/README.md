# WeatherApp

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 10.1.4.

## Development server

Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The app will automatically reload if you change any of the source files.

## App usage

1. To be able to search for locations and see their respective current weather.
2. To be able to select a location and see the 5 day weather forecast and details about current weather.

## App work flow

1. Select city name on the left panel via type ahead feature.
2. Click on plus icon to add a city the Recently Searched locations
3. Click on any city in Recently Searched locations to get 5 days weather forecast. 
4. Click on clear button to clear Recently Searched locations.