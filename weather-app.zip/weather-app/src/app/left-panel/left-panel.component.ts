import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { DataService } from '../data.service';
import { Observable } from 'rxjs';
import {debounceTime, distinctUntilChanged, map} from 'rxjs/operators';

@Component({
  selector: 'app-left-panel',
  templateUrl: './left-panel.component.html',
  styleUrls: ['./left-panel.component.sass']
})
export class LeftPanelComponent implements OnInit {

  @Output() citySelected = new EventEmitter<any>();
  constructor(private dataService: DataService) { }
  citiesList = [];
  selectedCities = [];
  model: any;
  
  ngOnInit(): void {
    this.getCities();
  }

  getCities() {
    this.dataService.getCities().subscribe(cities => {
      this.citiesList = cities;
    });
  }

  searchNew = (text$: Observable<string>) =>
    text$.pipe(
      debounceTime(200),
      distinctUntilChanged(),
      map(term => term.length < 2 ? []
        : this.citiesList.filter(v => v.name.toLowerCase().indexOf(term.toLowerCase()) > -1).slice(0, 10))
    )
  
  formatter = (x: {name: string}) => x.name;

  selectCity(transactionType, model?, index?) {
    const currentCity = model ? model : this.model;
    if (currentCity && currentCity.id) {
      this.dataService.getCityWeatherById(currentCity.id).subscribe(weather => {
        if (transactionType === 'add') {
          this.addCityToList(weather, currentCity);
        } else if (transactionType === 'refresh') {
          this.updateWeatherInfo(weather, index);
        }
      });
    }
  }

  addCityToList(weather, currentCity) {
    const weatherInfo = this.getWeatherInfo(weather);
    currentCity.weatherInfo = weatherInfo;
    if (this.selectedCities.length === 8) {
      this.selectedCities.pop();
    }
    this.selectedCities.unshift(currentCity);
    this.model = {};
  }

  getWeatherInfo(weather) {
    return {
      temperature: weather.main.temp,
      condition: weather.weather[0].main,
      icon: this.dataService.getIconUrl(weather.weather[0].icon)
    }
  } 

  updateWeatherInfo(weather, index) {
    this.selectedCities[index].weatherInfo = this.getWeatherInfo(weather)
  }

  removeCity(index) {
    this.selectedCities.splice(index, 1);
  }

  clearList() {
    this.selectedCities = [];
  }

  detailEvent(selectedCity) {
    this.citySelected.emit(selectedCity);
  }


}
