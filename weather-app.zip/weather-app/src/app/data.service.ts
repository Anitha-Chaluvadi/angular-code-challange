import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DataService {

  constructor(private http: HttpClient) { }

  private cities = './assets/city.list.json';
  private apiKey = 'c51223c219d6aec8cb8c5210449bd859'
  private weatherByCityId = 'http://api.openweathermap.org/data/2.5/weather?id=';
  private forecastByCityId = 'http://api.openweathermap.org/data/2.5/forecast?id=';
  private units = '&units=metric';
  private baseIcon = 'http://openweathermap.org/img/wn/';

  getCities(): Observable<any[]> {
    return this.http.get<any[]>(this.cities);
  }

  getCityWeatherById(id): Observable<any> {
    return this.http.get<any>(this.weatherByCityId + id + this.units + '&appid=' + this.apiKey);
  }

  getCityforecastByCityId(id): Observable<any> {
    return this.http.get<any>(this.forecastByCityId + id + this.units + '&appid=' + this.apiKey);
  }

  getIconUrl(code) {
    return this.baseIcon + code + '.png';
  }
}
