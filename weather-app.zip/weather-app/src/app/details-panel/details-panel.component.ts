import { Component, OnInit, Input, SimpleChanges, OnChanges  } from '@angular/core';
import { DataService } from '../data.service';

@Component({
  selector: 'app-details-panel',
  templateUrl: './details-panel.component.html',
  styleUrls: ['./details-panel.component.sass']
})
export class DetailsPanelComponent implements OnInit, OnChanges {

  @Input() currentCity: any;

  weatherDetails: any;

  constructor(private dataService: DataService) { }
  
  ngOnInit(): void {
    this.getForeCast();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.currentCity) {
      this.getForeCast();
    }
  }

  getForeCast() {
    if (this.currentCity.id) {
      this.dataService.getCityforecastByCityId(this.currentCity.id).subscribe(weather => {
        console.log('getForeCast ', weather);
        this.weatherDetails = {
          'current':  this.mapWeatherInfo(weather.list[0]),
          'foreCast': this.mapForecast(weather.list)
        }
        console.log('this.weatherDetails ', this.weatherDetails);
      });
      
    }
  }

  mapWeatherInfo(details) {
    return {
      temperature: details.main.temp,
      condition: details.weather[0].main,
      wind: details.wind,
      pressure: details.main.pressure,
      icon: this.dataService.getIconUrl(details.weather[0].icon)
    }
  }

  mapForecast(list) {
    const foreCast = [];
    let i = 5;
    const len  = list.length;
    console.log('len ', len);
    const currentDate = new Date();
    let count = 1;
    for (i = 5; i < len; i +=8) {
      console.log(i);
      foreCast.push({
        temp: list[i] && list[i].main.temp,
        date: this.getForeCastDate(currentDate.getDate(), count),
        dayOfWeek: this.getDayOfWeek(currentDate.getDate(), count),
        icon:this.dataService.getIconUrl(list[i].weather[0].icon)
      });
      count++;
    }
    return foreCast;
  }

  getForeCastDate(date, count) {
    return this.getNextDate(date, count).getDate();
  }

  getDayOfWeek(date, count) {
    return this.getDayOfWeekString(this.getNextDate(date, count).getDay());
  }

  getNextDate(date, count) {
    const newDate = new Date(); //date + count
    newDate.setDate(date + count);
    return newDate;
  }

  getDayOfWeekString(dayOfWeek) {
    let day = ''
    switch (dayOfWeek) {
      case 0:
        day = "Sun";
        break;
      case 1:
        day = "Mon";
        break;
      case 2:
         day = "Tue";
        break;
      case 3:
        day = "Wed";
        break;
      case 4:
        day = "Thu";
        break;
      case 5:
        day = "Fri";
        break;
      case 6:
        day = "Sat";
    }
    return day;
  }



}
