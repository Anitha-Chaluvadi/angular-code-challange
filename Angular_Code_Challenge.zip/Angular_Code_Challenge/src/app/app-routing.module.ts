import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { page_routes } from './app.routes';

const routes: Routes = [
  {
    path: (page_routes.details)+'/:id',
    loadChildren: () => import('./pages/details/details.module').then(m=>m.DetailsModule)
  },
  {
    path: '**',
    loadChildren: () => import('./pages/landing/landing.module').then(m=>m.LandingModule)
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
