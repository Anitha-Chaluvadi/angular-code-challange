export const page_routes = {
    landing: 'landing',
    details: 'details'
}