import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-master-layout',
  templateUrl: './master-layout.component.html',
  styleUrls: ['./master-layout.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class MasterLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
