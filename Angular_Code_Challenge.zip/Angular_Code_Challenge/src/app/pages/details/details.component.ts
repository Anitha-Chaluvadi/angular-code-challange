import { page_routes } from 'src/app/app.routes';
import { Component, Input, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { ApiServiceService } from 'src/app/services/api-service.service';

@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.scss']
})
export class DetailsComponent implements OnInit {

  @Input()
  selectedEntityId: string;

  public response: any;

  constructor(private apiService: ApiServiceService,
    private activatedRoute: ActivatedRoute,
    private router: Router) {
    this.activatedRoute.params.subscribe(paramMap => {
      this.selectedEntityId = paramMap['id'];
    });
  }

  ngOnInit(): void {
    this.apiService.getEntity(this.selectedEntityId).subscribe(response => {
      this.response = response;
    });
  }

  goBack() {
    this.router.navigate([page_routes.landing]);
  }

}
