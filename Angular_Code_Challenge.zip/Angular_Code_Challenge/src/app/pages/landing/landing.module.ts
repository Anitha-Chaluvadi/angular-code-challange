import { PaginatorComponent } from './../../components/paginator/paginator.component';
import { FilterComponent } from './../../components/filter/filter.component';
import { GridComponent } from './../../components/grid/grid.component';
import { TypeaheadComponent } from './../../components/typeahead/typeahead.component';
import { RouterModule, Routes } from '@angular/router';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LandingComponent } from './landing.component';
import { MasterLayoutComponent } from 'src/app/layouts/master-layout/master-layout.component';

const routes: Routes = [
  {
    path: '',
    component: LandingComponent
  }
];

@NgModule({
  declarations: [LandingComponent, TypeaheadComponent, GridComponent,
    FilterComponent, MasterLayoutComponent, PaginatorComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(routes)
  ]
})
export class LandingModule { }
