import { GridStateModel } from './../../services/api-model';
import { Observable, BehaviorSubject } from 'rxjs';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { page_routes } from 'src/app/app.routes';
import { ApiServiceService } from 'src/app/services/api-service.service';

@Component({
  selector: 'app-landing',
  templateUrl: './landing.component.html',
  styleUrls: ['./landing.component.scss']
})
export class LandingComponent implements OnInit {

  constructor(private router: Router,
    private apiService: ApiServiceService) { }

  gridState$: BehaviorSubject<GridStateModel>;

  ngOnInit(): void {
    this.gridState$ = this.apiService.GridState;
  }

  selectHandler(id: string) {
    this.router.navigate([page_routes.details, id]);
  }

  suggestionApiHandler(searchTerm: string) {
    return this.apiService.searchList(searchTerm);
  }

  rowSelectedHandler(id: string) {
    this.selectHandler(id);
  }

}
