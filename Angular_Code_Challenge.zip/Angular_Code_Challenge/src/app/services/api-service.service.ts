import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { FilterStateModel, GridStateModel, PaginationStateModel } from './api-model';

@Injectable({
  providedIn: 'root'
})
export class ApiServiceService {

  FilterState: BehaviorSubject<FilterStateModel> = new BehaviorSubject<FilterStateModel>({
    isByCityFilterSet: false,
    isByNameFilterSet: false,
    query_by_city: '',
    query_by_name: ''
  });

  PaginationState: BehaviorSubject<PaginationStateModel> = new BehaviorSubject<PaginationStateModel>({
    pageId: '0',
    per_page: '15'
  });

  GridState: BehaviorSubject<GridStateModel> = new BehaviorSubject<GridStateModel>({
    isDataLoaded: false
  });

  constructor(private http: HttpClient) { }

  setFilterState(byCity: string, byName: string) {
    const state: FilterStateModel = {
      isByCityFilterSet: false,
      isByNameFilterSet: false,
      query_by_city: '',
      query_by_name: ''
    };

    if (byCity) {
      state.isByCityFilterSet = true;
      state.query_by_city = byCity;
    }

    if (byName) {
      state.isByNameFilterSet = true;
      state.query_by_name = byName;
    }

    this.FilterState.next(state);
  }

  setPaginationState(per_page: string, pageId: string) {
    const state: PaginationStateModel = {
      pageId: per_page,
      per_page: pageId
    };

    this.PaginationState.next(state);
  }

  setGridState(isDataLoaded: boolean) {
    this.GridState.next({ isDataLoaded: isDataLoaded });
  }

  searchList(query: string) {
    return this.http.get('https://api.openbrewerydb.org/breweries/autocomplete?query=' + query);
  }

  getEntity(id: string) {
    return this.http.get('https://api.openbrewerydb.org/breweries/' + id);
  }

  getPageData(pageId: string, per_page: string, by_city: string = "", by_name: string = "") {
    return this.http.get(`https://api.openbrewerydb.org/breweries?page=${pageId}&per_page=${per_page}&by_city=${by_city}&by_name=${by_name}`);
  }
}
