export interface FilterStateModel {
    isByCityFilterSet: boolean;
    isByNameFilterSet: boolean;
    query_by_city: string;
    query_by_name: string;
  }
  
  export interface PaginationStateModel {
    per_page: string;
    pageId: string;
  }

  export interface GridStateModel {
    isDataLoaded: boolean;
  }