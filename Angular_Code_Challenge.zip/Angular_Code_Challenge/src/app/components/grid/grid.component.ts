import { Component, Input, OnInit, EventEmitter, Output } from '@angular/core';
import { combineLatest } from 'rxjs';
import { map, distinctUntilChanged } from 'rxjs/operators';
import { ApiServiceService } from 'src/app/services/api-service.service';

@Component({
  selector: 'app-grid',
  templateUrl: './grid.component.html',
  styleUrls: ['./grid.component.scss']
})
export class GridComponent implements OnInit {

  @Output()
  rowSelected: EventEmitter<string> = new EventEmitter<string>();

  @Input()
  public data?: any;

  constructor(private apiService: ApiServiceService) { }

  ngOnInit(): void {
    combineLatest([this.apiService.FilterState, this.apiService.PaginationState])
      .pipe(map(([filterState, pageState]) => {
        this.data = undefined;
        return this.apiService.getPageData(String(parseInt(pageState.pageId) + 1), pageState.per_page,
          filterState.query_by_city, filterState.query_by_name);
      }), distinctUntilChanged()).subscribe(response => {
        response.subscribe((data) => {
          this.data = data;
        })
      });
  }

  rowSelectedHandler(id: string) {
    this.rowSelected.emit(id);
  }

  onLinkClickHandler(e: Event) {
    e.stopPropagation();
  }

}
