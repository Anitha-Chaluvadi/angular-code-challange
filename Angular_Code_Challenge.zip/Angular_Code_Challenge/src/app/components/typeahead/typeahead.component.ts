import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged, filter } from 'rxjs/operators';

@Component({
  selector: 'app-typeahead',
  templateUrl: './typeahead.component.html',
  styleUrls: ['./typeahead.component.scss']
})
export class TypeaheadComponent implements OnInit {

  @Output()
  public selected: EventEmitter<string> = new EventEmitter<string>();

  @Input()
  public callbackFunc: Function;

  public suggestions: Response[] = [];

  public searchTerm$: Subject<string> = new Subject();

  public displaySpinner = false;

  public displayNoResults = false;

  public displayError = false;

  constructor() { }

  ngOnInit(): void {
    this.searchTerm$.pipe(
      filter(searchTerm => searchTerm !== ""),
      distinctUntilChanged(),
      debounceTime(500),
    ).subscribe((searchTerm) => {
      this.displaySpinner = true;
      this.callbackFunc(searchTerm)
        .subscribe((result: any) => {
          this.displaySpinner = false;
          this.suggestions = result;
          this.displayNoResults = this.suggestions.length === 0;
        }, (_error) => {
          this.displaySpinner = false;
          this.displayNoResults = false;
          this.displayError = true;
        });
    });
  }

  clearTypeahead() {
    this.suggestions = [];
    this.displayNoResults = false;
    this.displaySpinner = false;
    this.displayError = false;
  }

  onSearchHandler(target: { value: any; }) {
    if (target.value.trim() === "") {
      this.clearTypeahead();
    } else {
      this.searchTerm$.next(target.value.trim());
    }
  }

  selectSuggestionHandler(id: string) {
    this.clearTypeahead();
    if (id !== "") {
      this.selected.emit(id);
    }
  }

}
