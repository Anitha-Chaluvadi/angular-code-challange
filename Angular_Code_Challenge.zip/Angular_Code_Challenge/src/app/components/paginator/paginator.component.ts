import { distinctUntilChanged } from 'rxjs/operators';
import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import { ApiServiceService } from 'src/app/services/api-service.service';
import { pageModel } from './paginator.model';

@Component({
  selector: 'app-paginator',
  templateUrl: './paginator.component.html',
  styleUrls: ['./paginator.component.scss']
})
export class PaginatorComponent implements OnInit {

  @Input()
  displayLimit?: number = 5;

  @Input()
  paginationLimit?: number = 50;

  @Input()
  perPageResult?: number = 15;

  public active_page_id: string;

  public page_list_model: pageModel[] = [];

  constructor(private apiService: ApiServiceService) {
    for (let pageId = 0; pageId < this.displayLimit; pageId++) {
      this.page_list_model[pageId] = {
        value: pageId,
        isActive: false
      }
    }
    this.page_list_model[0].isActive = true;
  }

  getActivePageId() {
    let activeId = 0;
    this.page_list_model.forEach(page => {
      if (page.isActive) activeId = page.value;
    });
    return activeId;
  }

  ngOnInit(): void { }

  pageHandler(pageId: string) {
    let activePageId = this.getActivePageId();

    if ((pageId === 'L' && activePageId === 0) || (pageId === 'R' && activePageId === this.paginationLimit - 1)) {
      return;
    }

    this.page_list_model.find(page => page.value === activePageId).isActive = false;

    if (pageId === 'L') {
      if (activePageId === this.page_list_model[0].value) {
        this.page_list_model.unshift({
          value: activePageId - 1,
          isActive: true
        });
        this.page_list_model = this.page_list_model.slice(0, this.page_list_model.length - 1);
      } else {
        this.page_list_model.find(page => page.value === activePageId - 1).isActive = true;
      }
    } else if (pageId === 'R') {
      if (activePageId === this.page_list_model[this.page_list_model.length - 1].value) {
        this.page_list_model.push({
          value: activePageId + 1,
          isActive: true
        });
        this.page_list_model = this.page_list_model.slice(1);
      } else {
        this.page_list_model.find(page => page.value === activePageId + 1).isActive = true;
      }
    } else {
      if (parseInt(pageId) < this.displayLimit) {
        this.page_list_model[parseInt(pageId)].isActive = true;
      }
    }
    this.apiService.setPaginationState(String(this.getActivePageId()), String(this.perPageResult));
  }

}
