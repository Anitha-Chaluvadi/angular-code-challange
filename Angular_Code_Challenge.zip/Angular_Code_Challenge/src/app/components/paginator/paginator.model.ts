export interface pageModel {
    value: number;
    isActive: boolean;
}