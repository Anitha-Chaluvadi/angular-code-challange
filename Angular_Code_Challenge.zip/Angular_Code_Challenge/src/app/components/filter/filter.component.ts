import { filter, distinctUntilChanged, map } from 'rxjs/operators';
import { Component, OnInit } from '@angular/core';
import { ApiServiceService } from 'src/app/services/api-service.service';
import { combineLatest, Subject } from 'rxjs';

@Component({
  selector: 'app-filter',
  templateUrl: './filter.component.html',
  styleUrls: ['./filter.component.scss']
})
export class FilterComponent implements OnInit {

  public isFilterApplied = false;

  private nameSubject: Subject<string> = new Subject<string>();

  private citySubject: Subject<string> = new Subject<string>();

  constructor(private apiService: ApiServiceService) { }

  ngOnInit(): void {}

  filterHandler(cityQuery: { value: string; }, nameQuery: { value: string; }) {
    if (!cityQuery && !nameQuery) {
      return;
    }

    this.apiService.setFilterState(cityQuery.value, nameQuery.value);

    this.apiService.FilterState
      .subscribe(state=>{
        this.isFilterApplied = state.isByNameFilterSet || state.isByCityFilterSet;
      })
  }

  clearFilterHandler(cityQuery, nameQuery) {
    cityQuery.value = "";
    nameQuery.value = "";
    this.apiService.setFilterState(cityQuery.value, nameQuery.value);
  }

}
